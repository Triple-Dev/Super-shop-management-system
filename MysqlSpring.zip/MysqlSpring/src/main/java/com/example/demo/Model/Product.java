package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String name;
    private String productGroup;
    private long parchasePrice;
    private long salePrice;

    public Product(String name, String productGroup, long parchasePrice, long salePrice) {
        this.name = name;
        this.productGroup = productGroup;
        this.parchasePrice = parchasePrice;
        this.salePrice = salePrice;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", Group='" + productGroup + '\'' +
                ", parchasePrice=" + parchasePrice +
                ", salePrice=" + salePrice +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public long getParchasePrice() {
        return parchasePrice;
    }

    public void setParchasePrice(long parchasePrice) {
        this.parchasePrice = parchasePrice;
    }

    public long getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(long salePrice) {
        this.salePrice = salePrice;
    }

    public Product() {

    }
}
