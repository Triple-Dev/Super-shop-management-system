package com.example.demo.controller;

import com.example.demo.Model.Product;
import com.example.demo.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class DemoController {

    @Autowired
    ProductRepo productRepo;


    @RequestMapping("addProduct")
   public String addProduct(Product product){

   //     Product product=new Product("ridmi note4","Mobile",13000,14000);
   //     productRepo.save(product);

        productRepo.save(product);
        return "home";
   }

    @RequestMapping("products")
    @ResponseBody
     public ModelAndView showProductList(){
      List<Product> productList= (List<Product>) productRepo.findAll();
      ModelAndView mv=new ModelAndView("products");
       mv.addObject("products",productList);

      return mv;
    }



    //@RequestMapping("product")
   // @ResponseBody
   // public Product findProduct(@RequestParam int productId){
   //     Product product=productRepo.findById(productId).orElse(null);
    //    return product;
    //}
}
